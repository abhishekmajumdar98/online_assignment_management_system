<html>
    <style>
    table, th, td {
    border: 1px solid blue;
}
        h1{
    background-color: royalblue;
    color: white;
    font-family: thoma;
            text-align: center;
}
        #footer{
   margin-top: 12%;
  background-color: blanchedalmond;
    text-align: center;
 
}
        img {
            margin-left: 600px;
            margin-top: 100px;
        }
    </style>
    <h1>Details feed By Students :</h1>
     <table>
  <tr>
      <b>Personal Details:</b>
    <th>Applicant Name </th>
    <th>Date of Birth</th>
       <th>Father's Name</th>
      <th> Mother's Name</th>
      <th> Gender</th>
      <th> Religion</th>
      <th>Email-id</th>
      <th>Mobile No.</th>
      <th>Address</th>
   
  </tr>
         <tr>
         <td>
        <?php echo $_POST['aname'] ?> 
       </td>
             <td>
        <?php echo $_POST['dob'] ?> 
       </td>
             <td>
        <?php echo $_POST['fname'] ?> 
       </td>
             <td>
        <?php echo $_POST['mname'] ?> 
       </td>
             <td>
        <?php echo $_POST['gender'] ?> 
       </td>
             <td>
        <?php echo $_POST['religion'] ?> 
       </td>
             <td>
        <?php echo $_POST['email'] ?> 
       </td>
             <td>
        <?php echo $_POST['mobile'] ?> 
       </td>
             <td>
        <?php echo $_POST['address'] ?> 
       </td>
         </tr>


     <table>
  <tr>
      <b>Exam Details:</b>
    <th>College Code </th>
    <th>Form No</th>
       <th>Pssword</th>
      <th> PRN Status</th>
      <th> Branch</th>
      <th> Exam Center</th>
      <th>Exam group</th>
      <th>Exam Month</th>
      <th>Exam Year</th>
   
  </tr>
     <tr>
              <td>
        <?php echo $_POST['ccode'] ?> 
       </td>
              <td>
        <?php echo $_POST['form'] ?> 
       </td>
              <td>
        <?php echo $_POST['password'] ?> 
       </td>
              <td>
        <?php echo $_POST['prnstatus'] ?> 
       </td>
              <td>
        <?php echo $_POST['branch'] ?> 
       </td>
              <td>
        <?php echo $_POST['ecenter'] ?> 
       </td>
              <td>
        <?php echo $_POST['egroup'] ?> 
       </td>
              <td>
        <?php echo $_POST['month'] ?> 
       </td>
              <td>
        <?php echo $_POST['year'] ?> 
       </td>
         </tr>  </table>
         <img src="Shivaji-University-Kolhapur.jpeg" width="10%">
         <div id="footer">
        <p align="center" ></p>Developed by Computer Sol 
        </div>
</html>